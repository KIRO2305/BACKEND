window.addEventListener('DOMContentLoaded', () => {
  const slider = document.querySelector('.slider');
  document.getElementById('prev').onclick = () => slider.scrollBy({ left: -300, behavior: 'smooth' });
  document.getElementById('next').onclick = () => slider.scrollBy({ left: 300, behavior: 'smooth' });
});
